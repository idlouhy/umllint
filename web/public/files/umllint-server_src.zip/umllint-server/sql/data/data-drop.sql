-- umlcheck
-- 2013-10-13_002
-- umlcheck@dlouho.net

TRUNCATE public.pattern;
TRUNCATE public.reference;
TRUNCATE public.severity;
TRUNCATE public.category;