package net.umllint.common.model.xmi.model;

/**
 * Created by idlouhy on 4/16/14.
 */
public class XMIDocument {
}
