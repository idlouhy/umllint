package net.umllint.common.model.uml.classes;


import net.umllint.common.model.uml.classes.common.UMLAbstractClass;

public class UMLEnumeration extends UMLAbstractClass {

    public UMLEnumeration() {
        setXmiType("uml:Enumeration");
    }

}
