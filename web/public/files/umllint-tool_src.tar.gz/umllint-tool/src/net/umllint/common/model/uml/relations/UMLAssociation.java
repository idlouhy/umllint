package net.umllint.common.model.uml.relations;


public class UMLAssociation extends UMLAbstractRelation {

    public UMLAssociation() {
        setXmiType("uml:Association");
    }
}
