package net.umllint.common.model.uml.classes.common;


public class UMLElement extends UMLAbstractClass {

}
